<?php
require_once("BandAccount.php");

/*
$bankCustomer1 = new BankAccount();
$bankCustomer2 = new BankAccount();
*/
//var_dump($bankCustomer1);
//resultat du var_dump object(BankAccount)#1 (2) { ["accountNumber"]=> NULL ["balance"]=> NULL } 
/*
$bankCustomer1->accountNumber = 1;
$bankCustomer1->balance = 1000000;
$bankCustomer2->accountNumber = 2;
$bankCustomer2->balance = 2000000; 

echo "Premier utilisateur"."<br>";
echo "Numero :  " + $bankCustomer1->accountNumber."<br>";
echo "Salaire:   "+ $bankCustomer1->balance."<br>";


echo "Deuxième utilisateur"."<br>";
echo "Numero :  " + $bankCustomer2->accountNumber."<br>";
echo "Salaire:   "+ $bankCustomer2->balance."<br>";
*/

$bankCustomer1 = new BankAccount(1001, 10000000);
$bankCustomer2 = new BankAccount(1002, 20000000);

$bankCustomer1->affichage();
$bankCustomer2->affichage();






