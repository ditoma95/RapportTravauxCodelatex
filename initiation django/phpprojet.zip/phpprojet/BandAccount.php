<?php 
    //création de la classe
    class BankAccount{
        private $accountNumber;
        private $balance;   
        //constructeur
        public function __construct($accountNumber, $balance){
            $this->accountNumber = $accountNumber;
            $this->balance = $balance;
        }
        //getters
        public function getAccountNumber(){
            return $this->accountNumber;
        }
        public function getBalance(){
            return $this->balance;
        }
        //setters
        public function setAccountNumber($accountNumber){
            $this->accountNumber = $accountNumber;
        }
        public function setBalance($balance){
            $this->balance = $balance;
        }
        //method afficher
        public function affichage(){
            echo "Number :".$this->getAccountNumber()."  ⟶Salaire : ".$this->getBalance()."<br>";
        }
    }

?>